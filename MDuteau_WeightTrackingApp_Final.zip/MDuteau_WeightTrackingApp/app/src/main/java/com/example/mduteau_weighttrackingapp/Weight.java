package com.example.mduteau_weighttrackingapp;

public class Weight {
    private long mId;
    private String mWeight;
    private String mDate;

    // default constructor
    public Weight() {}

    // Constructor that takes params ID, weight, and date
    public Weight(long id, String weight, String date) {
        mId = id;
        mWeight = weight;
        mDate = date;
    }

    public long getId() {
        return mId;
    }

    public void setId(long id) {
        this.mId = id;
    }

    public String getWeight() {
        return mWeight;
    }

    public void setWeight(String weight) {
        this.mWeight = weight;
    }

    public String getDate() {
        return mDate;
    }

    public void setDate(String date) {
        this.mDate = date;
    }
}
