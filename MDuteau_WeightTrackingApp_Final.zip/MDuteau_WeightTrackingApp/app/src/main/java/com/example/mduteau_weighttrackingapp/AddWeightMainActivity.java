package com.example.mduteau_weighttrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class AddWeightMainActivity extends AppCompatActivity {
    private WeightAppDatabase weightAppDatabase;
    private TextView mTodayDate;
    private EditText mDailyWeight;
    private Button mAddDailyWeightButton;
    private String sDailyWeight;
    private Boolean addedDailyWeight = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight_main);
        setSupportActionBar(findViewById(R.id.extras_appbar));
        mTodayDate = findViewById(R.id.textViewTodayDate);
        mDailyWeight = findViewById(R.id.editTextTextDailyWeightHistory);
        mAddDailyWeightButton = findViewById(R.id.buttonAddDailyWeightHistory);

        ActionBar actionBar = getSupportActionBar();
        assert actionBar != null;
        actionBar.setDisplayHomeAsUpEnabled(true);

        SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault());
        Calendar current = Calendar.getInstance();
        df.setCalendar(current);
        String currentDate = df.format(current.getTime());
        mTodayDate.setText(currentDate);

        weightAppDatabase = WeightAppDatabase.getInstance(getApplicationContext());

        mDailyWeight.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before,
                                      int count) {
                sDailyWeight = mDailyWeight.getText().toString();
            }
        });

        mAddDailyWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (sDailyWeight != null) {
                    Weight dailyWeight = new Weight();
                    dailyWeight.setWeight(sDailyWeight);
                    dailyWeight.setDate(currentDate);
                    // if there is a daily weight with today's date, update the weight rather than adding it
                    if (weightAppDatabase.getDailyWeight().getDate().matches(currentDate)) {
                        addedDailyWeight = weightAppDatabase.updateWeight(weightAppDatabase.getDailyWeight(), dailyWeight);
                    } else { // else we add the weight
                        addedDailyWeight = weightAppDatabase.addWeight(sDailyWeight, currentDate);
                    }

                    if (addedDailyWeight) {
                        startActivity(new Intent(AddWeightMainActivity.this, MainActivity.class));
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Enter a daily weight!", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.extras_appbar_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            this.finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
