package com.example.mduteau_weighttrackingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.text.TextWatcher;
import android.text.Editable;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class LoginActivity extends AppCompatActivity {
    private EditText mUsername;
    private EditText mPassword;
    private Button mLogin;
    private Button mRegister;
    private WeightAppDatabase weightAppDatabase;
    public boolean validatedUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        mUsername = findViewById(R.id.editTextTextUsername);
        mPassword = findViewById(R.id.editTextTextPassword);
        final String[] sUsername = new String[1];
        final String[] sPassword = new String[1];
        mLogin = findViewById(R.id.buttonLogin);
        mRegister = findViewById(R.id.buttonRegister);

        weightAppDatabase = WeightAppDatabase.getInstance(getApplicationContext());
        validatedUser = false;

        mUsername.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before,
                                      int count) {
                sUsername[0] = mUsername.getText().toString();
            }
        });

        mPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before,
                                      int count) {
                sPassword[0] = mPassword.getText().toString();
            }
        });

            mLogin.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // check that the user exists within the database and the credentials are valid
                    validatedUser = isValidatedUser(weightAppDatabase, sUsername[0], sPassword[0]);
                    loginUser(validatedUser);
                }
            });

            mRegister.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // baseline parameters for appropriate credentials, ensuring each field is at least 8 characters
                    if (sUsername[0].length() < 8 || sPassword[0].length() < 8) { // notify user if entries do not constrain to requirements
                        Toast.makeText(getApplicationContext(), "Usernames and passwords must be greater than 8 characters", Toast.LENGTH_SHORT).show();
                    } else { // register new user to db if credentials within the dictated limits
                        registerUser(weightAppDatabase, sUsername[0], sPassword[0]);
                    }
                }
            });

    }

    // method to validate user credentials
    public boolean isValidatedUser(WeightAppDatabase weightAppDatabase, String username, String password) {
        return weightAppDatabase.validateUser(username, password);
    }

    public void loginUser(boolean validatedUser) {
        // will only login with valid credentials
        if (validatedUser) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        } else { // otherwise notify user of invalid entry
            Toast.makeText(getApplicationContext(), "Username or password is incorrect!", Toast.LENGTH_SHORT).show();
        }
    }

    public void registerUser(WeightAppDatabase weightAppDatabase, String username, String password) {
        if (!weightAppDatabase.doesUserExist(username)) { // check if user exists prior to registering
            weightAppDatabase.addNewUser(username, password);
            Toast.makeText(getApplicationContext(), "You've been registered! Login now!", Toast.LENGTH_SHORT).show();
        } else { // notify user if username already exists within db
            Toast.makeText(getApplicationContext(), "This user already exists!", Toast.LENGTH_SHORT).show();
        }
    }

}
