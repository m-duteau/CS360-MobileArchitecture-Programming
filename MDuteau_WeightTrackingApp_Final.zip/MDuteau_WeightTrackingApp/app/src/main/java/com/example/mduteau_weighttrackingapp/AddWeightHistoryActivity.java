package com.example.mduteau_weighttrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class AddWeightHistoryActivity extends AppCompatActivity {
    private WeightAppDatabase weightAppDatabase;
    private TextView mDate;
    private EditText mWeight;
    private Button mAddWeight;
    private String sWeight;
    private String sDate;
    private Boolean addedDailyWeight = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight_history);
        setSupportActionBar(findViewById(R.id.extras_appbar));
        mDate = findViewById(R.id.editTextDate);
        mWeight = findViewById(R.id.editTextTextDailyWeightHistory);
        mAddWeight = findViewById(R.id.buttonAddDailyWeightHistory);

        ActionBar actionBar = getSupportActionBar();
        assert actionBar != null;
        actionBar.setDisplayHomeAsUpEnabled(true);

        weightAppDatabase = WeightAppDatabase.getInstance(getApplicationContext());

        mWeight.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before,
                                      int count) {
                sWeight = mWeight.getText().toString();
            }
        });

        mDate.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before,
                                      int count) {
                sDate = mDate.getText().toString();
            }
        });

        mAddWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (sWeight != null && sDate != null) {
                    // date should be entered as ##/##/#### per the prompt
                    if (!sDate.matches("\\d{2}[/]\\d{2}[/]\\d{4}")) {
                        // notify user if they've entered otherwise
                        Toast.makeText(getApplicationContext(), "Invalid date format!", Toast.LENGTH_SHORT).show();
                    } else {
                        int iDay = Integer.parseInt(sDate.substring(0, 2));
                        int iMonth = Integer.parseInt(sDate.substring(3, 5));
                        String sMonth = "";
                        int iYear = Integer.parseInt(sDate.substring(6, 10));

                        // check that values are within reasonable date ranges
                        if (!((iDay > 31 || iDay < 0) && (iMonth > 12 || iMonth < 0) && (iYear > 2024 || iYear < 0))) {
                            // save first three letter of Month name to string per SimpleDateFormat in use within db
                            for (int i = 0; i < 13; ++i) {
                                if (i == iMonth) {
                                    if (i == 1) {
                                        sMonth = "Jan";
                                    }
                                    else if (i == 2) {
                                        sMonth = "Feb";
                                    }
                                    else if (i == 3) {
                                        sMonth = "Mar";
                                    }
                                    else if (i == 4) {
                                        sMonth = "Apr";
                                    }
                                    else if (i == 5) {
                                        sMonth = "May";
                                    }
                                    else if (i == 6) {
                                        sMonth = "Jun";
                                    }
                                    else if (i == 7) {
                                        sMonth = "Jul";
                                    }
                                    else if (i == 8) {
                                        sMonth = "Aug";
                                    }
                                    else if (i == 9) {
                                        sMonth = "Sep";
                                    }
                                    else if (i == 10) {
                                        sMonth = "Oct";
                                    }
                                    else if (i == 11) {
                                        sMonth = "Nov";
                                    }
                                    else if (i == 12) {
                                        sMonth = "Dec";
                                    }
                                }
                            }
                            String sNewDate = sDate.substring(0, 2) + "-" + sMonth + "-" + sDate.substring(6, 10);

                            addedDailyWeight = weightAppDatabase.addWeight(sWeight, sNewDate);

                            if (addedDailyWeight) { // return to WeightsHistory only if weight was added
                                startActivity(new Intent(AddWeightHistoryActivity.this, WeightsHistoryActivity.class));
                            }
                        } else {
                            Toast.makeText(getApplicationContext(), "Invalid date format!", Toast.LENGTH_SHORT).show();
                        }
                    }
                } else { // EditText was left blank, notify user
                    Toast.makeText(getApplicationContext(), "Enter a weight!", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.extras_appbar_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            this.finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
