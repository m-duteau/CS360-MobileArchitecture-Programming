package com.example.mduteau_weighttrackingapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class WeightsHistoryActivity extends AppCompatActivity {

    private TextView mWeights;
    private TextView mDates;
    private List<Weight> weightsList;
    private WeightAppDatabase weightAppDatabase;
    private FloatingActionButton mAddWeightButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weights_history);
        setSupportActionBar(findViewById(R.id.extras_appbar));

        ActionBar actionBar = getSupportActionBar();
        assert actionBar != null;
        actionBar.setDisplayHomeAsUpEnabled(true);

        weightAppDatabase = WeightAppDatabase.getInstance(getApplicationContext());

        mAddWeightButton = findViewById(R.id.floatingAddWeight);
        mWeights = findViewById(R.id.weightValues);
        mDates = findViewById(R.id.weightDates);

        // populate a list from the db's entries using db method getAllDailyWeights()
        weightsList = weightAppDatabase.getAllDailyWeights();
        if (!weightsList.isEmpty()) {
            loadWeightsList(weightsList);
        }

        mAddWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(WeightsHistoryActivity.this, AddWeightHistoryActivity.class));
            }
        });
    }

    void loadWeightsList(List<Weight> weightsList) {
        String stringWeights = "";
        String stringDates = "";

        // attempting to populate a TextView with a string containing newlines
        // turns out this doesn't work, or db is not storing more than one weight?
        // RecyclerView was probably needed here...
        for (int i = 0; i < weightsList.size(); ++i) {
            stringWeights += (weightsList.get(i).getWeight());
            stringDates += (weightsList.get(i).getDate());
            if (i != weightsList.size() - 1) {
                stringWeights += (" lbs\n");
                stringDates += ("\n");
            } else {
                stringWeights += (" lbs");
            }
        }

        // Weight and Date columns are populated with separate data relative to the category
        mWeights.setText(stringWeights);
        mDates.setText(stringDates);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.extras_appbar_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            startActivity(new Intent(WeightsHistoryActivity.this, MainActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}


