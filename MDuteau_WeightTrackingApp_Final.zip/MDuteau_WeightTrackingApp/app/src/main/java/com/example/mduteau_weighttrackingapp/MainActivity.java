package com.example.mduteau_weighttrackingapp;

import android.app.Notification;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.content.Intent;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private View view;

    private WeightAppDatabase mDatabase;
    private TextView mCurrentGoalWeight;
    private TextView mCurrentDailyWeight;
    private GoalWeight mGoalWeight;
    private Weight mDailyWeight;
    private String sCurrentDailyWeight;
    private String sCurrentGoalWeight;
    private Button mAddDailyWeightButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setSupportActionBar(findViewById(R.id.main_appbar));

        mDatabase = WeightAppDatabase.getInstance(getApplicationContext());
        mCurrentGoalWeight = findViewById(R.id.textViewGoalWeight);
        mCurrentDailyWeight = findViewById(R.id.textViewCurrentWeight);
        mAddDailyWeightButton = findViewById(R.id.buttonAddTodayWeight);

        mDailyWeight = mDatabase.getDailyWeight();
        mGoalWeight = mDatabase.getGoalWeight();

        // displays goal weight when a goal weight exists
        if (mGoalWeight != null) {
            sCurrentGoalWeight = mGoalWeight.getWeight();
            mCurrentGoalWeight.setText(sCurrentGoalWeight);
        } else { // otherwise immediately prompt user to enter a goal weight
            startActivity(new Intent(MainActivity.this, UpdateGoalWeightActivity.class));
        }

        // display daily weight if one exists for the current date
        if (mDailyWeight != null) {
            sCurrentDailyWeight = mDailyWeight.getWeight();
            mCurrentDailyWeight.setText(sCurrentDailyWeight);

        } else { // otherwise prompt user to enter their weight for the day
            mCurrentDailyWeight.setText("Enter today's weight!");
        }

        // update goal weight when goal weight TextView is clicked
        mCurrentGoalWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, UpdateGoalWeightActivity.class));
            }
        });

        mAddDailyWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, AddWeightMainActivity.class));
            }
        });

    }

    // methods for the appbar to open either weight history or settings screen
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.main_appbar_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        // Determine which menu option was selected
        if (item.getItemId() == R.id.action_weight_history) {
            onHistoryClick(view);
            return true;
        }
        else if (item.getItemId() == R.id.action_settings) {
            onSettingsClick(view);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void onHistoryClick(View view) {
        Intent intent = new Intent(this, WeightsHistoryActivity.class);
        startActivity(intent);
    }

    public void onSettingsClick(View view) {
        Intent intent = new Intent(this, SettingsActivity.class);
        startActivity(intent);
    }

}