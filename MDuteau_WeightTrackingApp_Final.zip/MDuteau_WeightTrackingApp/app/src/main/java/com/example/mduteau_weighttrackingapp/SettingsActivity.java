package com.example.mduteau_weighttrackingapp;

import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.CompoundButton;
import android.Manifest;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.content.ContextCompat;

public class SettingsActivity extends AppCompatActivity {
    SwitchCompat SMSSwitch;
    boolean receiveSMSNotifs = false;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        setSupportActionBar(findViewById(R.id.extras_appbar));
        SMSSwitch = findViewById(R.id.sms_switch);

        ActionBar actionBar = getSupportActionBar();
        assert actionBar != null;
        actionBar.setDisplayHomeAsUpEnabled(true);

        SMSSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (buttonView.isPressed()) {
                    SMSSwitch.setChecked(true);
                    receiveSMSNotifs = true;
                } else {
                    SMSSwitch.setChecked(false);
                    receiveSMSNotifs = false;
                }
                savePreferences();
            }
        });

        // retrieve default preferences
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        receiveSMSNotifs = sharedPreferences.getBoolean("pref_receive_notifications", false);
        // keep SMSSwitch checked if the user has already OK'd SMS notifications
        if (receiveSMSNotifs && ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            SMSSwitch.setChecked(true);
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.extras_appbar_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            this.finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // apply any changes made to shared preferences
    private void savePreferences() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("pref_receive_notifications", receiveSMSNotifs);
        editor.apply();
    }
}
