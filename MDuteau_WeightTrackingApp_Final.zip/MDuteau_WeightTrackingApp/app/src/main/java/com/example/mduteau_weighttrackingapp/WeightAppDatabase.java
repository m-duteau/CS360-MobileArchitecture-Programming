package com.example.mduteau_weighttrackingapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class WeightAppDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "weightapp.db";
    private static final int VERSION = 1;
    private static WeightAppDatabase sWeightAppDatabase; // singleton of the db

    // Factory method for creating a singleton or getting an existing singleton
    public static WeightAppDatabase getInstance(Context context) {
        if (sWeightAppDatabase == null) {
            sWeightAppDatabase = new WeightAppDatabase(context);
        }
        return sWeightAppDatabase;
    }

    // Class made singleton by private instantiation
    private WeightAppDatabase (Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    // Class of weights table
    private static final class WeightTable {
        private static final String TABLE = "weights";
        private static final String COL_ID = "_id";
        private static final String COL_WEIGHT = "weight";
        private static final String COL_DATE = "date";
    }

    // Class of goal weight table
    private static final class GoalWeightTable {
        private static final String TABLE = "goal_weights";
        private static final String COL_ID = "_id";
        private static final String COL_WEIGHT = "weight";
    }

    // Class of users table
    private static final class Users {
        private static final String TABLE = "users";
        private static final String COL_ID = "_id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + WeightTable.TABLE + " (" +
                WeightTable.COL_ID + " integer primary key autoincrement, " +
                WeightTable.COL_WEIGHT + " text, " +
                WeightTable.COL_DATE + " text)");
        db.execSQL("create table " + GoalWeightTable.TABLE + " (" +
                GoalWeightTable.COL_ID + " integer primary key autoincrement, " +
                GoalWeightTable.COL_WEIGHT + " text)");
        db.execSQL("create table " + Users.TABLE + " (" +
                Users.COL_ID + " integer primary key autoincrement, " +
                Users.COL_USERNAME + " text, " +
                Users.COL_PASSWORD + " text)");
    }

    @Override
    public void onUpgrade (SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + WeightTable.TABLE);
        db.execSQL("drop table if exists " + GoalWeightTable.TABLE);
        db.execSQL("drop table if exists " + Users.TABLE);
        onCreate(db);
    }

    // Create a new user -- will fail if user already exists
    public void addNewUser(String username, String password) {
        // check if user already exists
        if (doesUserExist(username)) {
            return;
        }

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(Users.COL_USERNAME, username);
        values.put(Users.COL_PASSWORD, password);

        long userId = db.insert(Users.TABLE, null, values);
    }

    // Check if username already exists in db
    public boolean doesUserExist(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "SELECT * FROM " + Users.TABLE + " WHERE username = ?";

        Cursor cursor = db.rawQuery(sql, new String[]{username});
        // returns true if user exists, i.e., usernames that match > 0
        boolean userExists = (cursor.getCount() > 0);
        cursor.close();

        return userExists;
    }

    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "SELECT * FROM " + Users.TABLE + " WHERE (username = ? AND password = ?)";

        Cursor cursor = db.rawQuery(sql, new String[]{username, password});
        // will return true when a db entry contains username/password combo matching the user input
        boolean validatedUser = (cursor.getCount() == 1);
        cursor.close();

        return validatedUser;
    }

    public boolean addWeight(String weight, String date) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(WeightTable.COL_WEIGHT, weight);
        values.put(WeightTable.COL_DATE, date);

        long weightId = db.insert(WeightTable.TABLE, null, values);

        return weightId != -1;
    }

    public boolean updateWeight(Weight oldWeight, Weight newWeight) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(WeightTable.COL_WEIGHT, newWeight.getWeight());
        values.put(WeightTable.COL_DATE, newWeight.getDate());

        int weightUpdated = db.update(WeightTable.TABLE, values,
                WeightTable.COL_ID + "=?", new String[]{String.valueOf(oldWeight.getId())}
        );

        return weightUpdated > 0;
    }

    public boolean deleteWeight(Weight weight) {
        SQLiteDatabase db = getWritableDatabase();

        int weightDeleted = db.delete(WeightTable.TABLE, WeightTable.COL_ID + " = ?",
                new String[]{String.valueOf(weight.getId())});

        return weightDeleted > 0;
    }

    public List<Weight> getAllDailyWeights() {
        List<Weight> dailyWeights = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + WeightTable.TABLE + " order by " + WeightTable.COL_DATE + " DESC Limit 1";
        Cursor cursor = db.rawQuery(sql, null);
        // populating a list of all weight within the db to return
        if (cursor.moveToFirst()) {
            do {
                Weight weight = new Weight();
                weight.setWeight(cursor.getString(1));
                weight.setDate(cursor.getString(2));
                dailyWeights.add(weight);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return dailyWeights;
    }

    public Weight getDailyWeight() {
        SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault());
        Calendar current = Calendar.getInstance();
        df.setCalendar(current);
        String currentDate = df.format(current.getTime());
        Weight recentWeight;
        Weight noCurrentWeight = new Weight();

        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + WeightTable.TABLE + " order by " + WeightTable.COL_DATE + " DESC Limit 1";
        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.moveToFirst()) {
            recentWeight = new Weight();
            recentWeight.setId(cursor.getLong(0));
            recentWeight.setWeight(cursor.getString(1));
            recentWeight.setDate(cursor.getString(2));
            String recentWeightDate = recentWeight.getDate();

            // we want to verify that the daily weight's date matches the current date
            if (recentWeightDate.matches(currentDate)) {
                cursor.close();
                db.close();
                return recentWeight;
            }

            cursor.close();
        }

        // return empty weight if no weight available with the current date
        noCurrentWeight.setWeight("");
        noCurrentWeight.setDate("");
        return noCurrentWeight;
    }

    public boolean addGoal(GoalWeight goalWeight) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(GoalWeightTable.COL_WEIGHT, goalWeight.getWeight());

        long goalId = db.insert(GoalWeightTable.TABLE, null, values);

        return goalId != -1;
    }

    public boolean updateGoal(GoalWeight goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(GoalWeightTable.COL_WEIGHT, goalWeight.getWeight());

        int goalUpdated = db.update(GoalWeightTable.TABLE, values, GoalWeightTable.COL_ID + " = ?",
                new String[]{String.valueOf((goalWeight.getId()))});

        return goalUpdated > 0;
    }

    public GoalWeight getGoalWeight() {
        GoalWeight goalWeight = null;

        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + GoalWeightTable.TABLE;
        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.moveToFirst()) {
            goalWeight = new GoalWeight();
            goalWeight.setId(cursor.getLong(0));
            goalWeight.setWeight(cursor.getString(1));
        }
        cursor.close();

        return goalWeight;
    }

}
