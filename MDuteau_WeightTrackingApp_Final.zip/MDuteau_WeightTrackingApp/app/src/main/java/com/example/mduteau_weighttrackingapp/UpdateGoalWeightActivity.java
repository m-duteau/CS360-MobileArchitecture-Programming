package com.example.mduteau_weighttrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class UpdateGoalWeightActivity extends AppCompatActivity {
    private WeightAppDatabase weightAppDatabase;
    private EditText mGoalWeight;
    private String sGoalWeight;
    private Boolean addedGoalWeight = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_goal_weight);
        setSupportActionBar(findViewById(R.id.extras_appbar));

        ActionBar actionBar = getSupportActionBar();
        assert actionBar != null;
        actionBar.setDisplayHomeAsUpEnabled(true);

        mGoalWeight = findViewById(R.id.editTextUpdateGoalWeight);
        Button mUpdateGoalWeightButton = findViewById(R.id.buttonUpdateGoalWeight);

        weightAppDatabase = WeightAppDatabase.getInstance(getApplicationContext());

        mGoalWeight.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before,
                                      int count) {
                sGoalWeight = mGoalWeight.getText().toString();
            }
        });

        mUpdateGoalWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // check that EditText field contains data
                if (!sGoalWeight.isEmpty()) {
                    GoalWeight goalWeight = new GoalWeight();
                    goalWeight.setWeight(sGoalWeight);
                    addedGoalWeight = weightAppDatabase.addGoal(goalWeight);
                } else { // otherwise notify user to enter goal weight
                    Toast.makeText(getApplicationContext(), "Enter a goal weight!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // return to MainActivity if a goal weight was entered
        if (addedGoalWeight) {
            startActivity(new Intent(UpdateGoalWeightActivity.this, MainActivity.class));
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.extras_appbar_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            this.finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
