package com.example.mduteau_weighttrackingapp;

public class GoalWeight {
    private long mId;
    private String mWeight;

    // default constructor
    public GoalWeight() {}

    // Constructor that takes params ID and weight
    public GoalWeight(long id, String weight, String date) {
        mId = id;
        mWeight = weight;
    }

    public long getId() { return mId; }

    public void setId(long id) {
        this.mId = id;
    }

    public String getWeight() {
        return mWeight;
    }

    public void setWeight(String weight) {
        this.mWeight = weight;
    }
}
